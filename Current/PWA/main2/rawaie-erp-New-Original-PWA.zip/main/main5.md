// ============================================================
// RW_Orders – أوردرات المبيعات (فلترة، تأكيد، حذف، رانشيت)
// ============================================================
var RW_Orders = (function() {
    var sortField = 'order_code', sortAsc = true, ordersData = [];
    var _sortIcons = {};

    function esc(s) {
        return String(s || '').replace(/[&<>]/g, function(m) {
            return m === '&' ? '&amp;' : m === '<' ? '&lt;' : '&gt;';
        });
    }

async function render() {
    var c = byId('rw-page-container');
    if (!c) return;
    safeText(byId('rw-header-title'), 'أوردرات المبيعات');
    safeText(byId('rw-header-subtitle'), 'عرض وإدارة جميع أوردرات المبيعات');

    safeHTML(c, '<div class="p-4">' +
        '<div class="bg-white rounded-2xl shadow-sm border p-4 mb-4">' +
            '<div class="flex flex-wrap justify-between items-center gap-2 mb-3">' +
                '<h3 class="font-bold text-lg">فلترة الأوردرات</h3>' +
                '<div class="flex gap-2">' +
                    '<button onclick="RW_Orders._applyFilters()" class="bg-blue-50 text-blue-600 px-3 py-1 rounded text-sm font-bold">تحديث</button>' +
                    '<button onclick="RW_Orders._showWithoutRS()" class="bg-amber-50 text-amber-600 px-3 py-1 rounded text-sm font-bold">بدون رانشيت</button>' +
                    '<button onclick="RW_Orders._resetFilters()" class="bg-gray-50 text-gray-600 px-3 py-1 rounded text-sm font-bold">إعادة تعيين</button>' +
                '</div>' +
            '</div>' +
            '<div class="grid grid-cols-2 md:grid-cols-6 gap-2">' +
                '<input type="date" id="f-date-from" onchange="RW_Orders._applyFilters()" class="p-2 bg-gray-50 rounded text-sm">' +
                '<input type="date" id="f-date-to" onchange="RW_Orders._applyFilters()" class="p-2 bg-gray-50 rounded text-sm">' +
                '<input type="text" id="f-cust" oninput="RW_Orders._applyFilters()" placeholder="العميل" class="p-2 bg-gray-50 rounded text-sm">' +
                '<select id="f-status" onchange="RW_Orders._applyFilters()" class="p-2 bg-gray-50 rounded text-sm">' +
                    '<option value="">الحالة</option>' +
                    '<option>Draft</option><option>Confirmed</option><option>Pending</option>' +
                    '<option>Invoiced</option><option>Delivered</option><option>Returned</option><option>Cancelled</option>' +
                '</select>' +
                '<input type="text" id="f-area" oninput="RW_Orders._applyFilters()" placeholder="المنطقة" class="p-2 bg-gray-50 rounded text-sm">' +
                '<input type="text" id="f-rs" oninput="RW_Orders._applyFilters()" placeholder="الرانشيت" class="p-2 bg-gray-50 rounded text-sm">' +
            '</div>' +
        '</div>' +
        '<div class="flex flex-wrap gap-3 mb-4">' +
            '<button onclick="RW_Orders._createRS()" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-bold shadow">' +
                '<i class="fa-solid fa-truck-fast ml-2"></i> رانشيت جديد' +
            '</button>' +
            '<button onclick="RW_Orders._appendRS()" class="bg-emerald-600 text-white px-4 py-2 rounded-lg font-bold shadow">' +
                '<i class="fa-solid fa-folder-plus ml-2"></i> ضم لرانشيت مفتوح' +
            '</button>' +
        '</div>' +
        '<div class="bg-white rounded-2xl shadow-sm border overflow-auto orders-table-container" style="max-height:65vh">' +
            '<table class="w-full min-w-[1200px]" id="orders-main-table">' +
                '<thead class="bg-gray-50 sticky top-0 z-10" id="orders-thead">' +
                    '<tr>' +
                        '<th class="p-3 text-center"><input type="checkbox" id="check-all" onchange="var cbs=document.querySelectorAll(\'.order-checkbox\');for(var i=0;i<cbs.length;i++)cbs[i].checked=this.checked;"></th>' +
                        '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Orders._sort(\'order_code\')">رقم الأوردر <i class="fa-solid fa-sort"></i></th>' +
                        '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Orders._sort(\'order_date\')">التاريخ <i class="fa-solid fa-sort"></i></th>' +
                        '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Orders._sort(\'customer_name\')">العميل والمنطقة <i class="fa-solid fa-sort"></i></th>' +
                        '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Orders._sort(\'itemsCount\')">عدد الأصناف <i class="fa-solid fa-sort"></i></th>' +
                        '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Orders._sort(\'total_amount\')">القيمة (EGP) <i class="fa-solid fa-sort"></i></th>' +
                        '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Orders._sort(\'order_status\')">الحالة <i class="fa-solid fa-sort"></i></th>' +
                        '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Orders._sort(\'runsheet_id\')">الرانشيت <i class="fa-solid fa-sort"></i></th>' +
                        '<th class="p-3 text-center text-xs font-bold uppercase">إجراءات</th>' +
                    '</tr>' +
                '</thead>' +
                '<tbody id="orders-table-body">' +
                    '<tr><td colspan="9" class="text-center py-8 text-gray-500">جاري التحميل...</td></tr>' +
                '</tbody>' +
            '</table>' +
            '<div id="orders-table-body-controls"></div>' +
        '</div>' +
    '</div>');

showLoader('جاري تحميل الأوردرات...');
try {
    var ordRes = await supabase.from('orders').select('*, runsheets(runsheet_code)');
    ordersData = ordRes.data || [];
    var detRes = await supabase.from('order_details').select('order_id, item_code');
    var details = detRes.data || [];
    var itemsCountMap = {};
    for (var i = 0; i < details.length; i++) {
        var oid = details[i].order_id;
        if (oid) itemsCountMap[oid] = (itemsCountMap[oid] || 0) + 1;
    }
    for (var j = 0; j < ordersData.length; j++) {
        // ✅ التصحيح الوحيد: استخدام ordersData[j].id بدلاً من ordersData[j].order_code
        ordersData[j].itemsCount = itemsCountMap[ordersData[j].id] || 0;
    }
    hideLoader();
} catch(e) {
    hideLoader();
    console.error(e);
}
_loadRunsheetCodes();
clearInterval(window._ordersRefreshInterval);
window._ordersRefreshInterval = setInterval(function() {
    if (RW_STATE.app.currentView === 'orders') {
        RW_Orders._refreshData();
    }
}, 30000);
// ✅ مستمع Supabase Realtime للمزامنة اللحظية
var channel = supabase
    .channel('orders-realtime')
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'orders' }, function(payload) {
        var updatedOrder = payload.new;
        if (updatedOrder && updatedOrder.id) {
            // تحديث الصف مباشرة في المصفوفة المحلية
            var found = false;
            for (var i = 0; i < ordersData.length; i++) {
                if (ordersData[i].id === updatedOrder.id) {
                    // دمج البيانات الجديدة مع القديمة للحفاظ على الحقول المخصصة مثل _runsheetCode و itemsCount
                    ordersData[i].total_amount = updatedOrder.total_amount;
                    ordersData[i].order_status = updatedOrder.order_status;
                    ordersData[i].amount_paid = updatedOrder.amount_paid;
                    // يمكن إضافة حقول أخرى حسب الحاجة
                    found = true;
                    break;
                }
            }
            if (found) {
                console.log('🔄 تحديث لحظي للأوردر:', updatedOrder.order_code, '| القيمة الجديدة:', updatedOrder.total_amount);
                // إعادة عرض الجدول بالبيانات المحدثة
                _applyFilters();
            }
        }
    })
    .subscribe();
}

    // ========== الفلترة والفرز ==========
    function _applyFilters() {
        var filtered = ordersData.slice();
        var fdEl = byId('f-date-from'), tdEl = byId('f-date-to'), custEl = byId('f-cust'),
            stEl = byId('f-status'), areaEl = byId('f-area'), rsEl = byId('f-rs');

        var fd = fdEl ? fdEl.value : '';
        var td = tdEl ? tdEl.value : '';
        var cust = custEl ? (custEl.value || '').toLowerCase() : '';
        var st = stEl ? stEl.value : '';
        var area = areaEl ? (areaEl.value || '').toLowerCase() : '';
        var rs = rsEl ? (rsEl.value || '').toLowerCase() : '';

        if (fd) filtered = filtered.filter(function(o) { return o.order_date >= fd; });
        if (td) filtered = filtered.filter(function(o) { return o.order_date <= td; });
        if (cust) filtered = filtered.filter(function(o) { return (o.customer_name || '').toLowerCase().indexOf(cust) !== -1; });
        if (st) filtered = filtered.filter(function(o) { return o.order_status === st; });
        if (area) filtered = filtered.filter(function(o) { return (o.area || '').toLowerCase().indexOf(area) !== -1; });
        if (rs) filtered = filtered.filter(function(o) { return (o.runsheet_id || '').toLowerCase().indexOf(rs) !== -1; });

        var sorted = filtered.sort(function(a, b) {
            var va = a[sortField] || '', vb = b[sortField] || '';
            if (sortField === 'total_amount' || sortField === 'itemsCount') {
                va = Number(va); vb = Number(vb);
            } else if (sortField === 'order_date') {
                va = new Date(va); vb = new Date(vb);
            } else {
                va = String(va).toLowerCase(); vb = String(vb).toLowerCase();
            }
            return (va < vb ? -1 : va > vb ? 1 : 0) * (sortAsc ? 1 : -1);
        });

        _renderTable(sorted);
    }

    function _resetFilters() {
        var ids = ['f-date-from', 'f-date-to', 'f-cust', 'f-status', 'f-area', 'f-rs'];
        for (var i = 0; i < ids.length; i++) {
            var el = byId(ids[i]);
            if (el) el.value = '';
        }
        _applyFilters();
    }

    function _showWithoutRS() {
        var filtered = ordersData.filter(function(o) { return !o.runsheet_id || o.runsheet_id === ''; });
        _renderTable(filtered);
    }

    function _sort(field) {
        if (sortField === field) {
            sortAsc = !sortAsc;
        } else {
            sortField = field;
            sortAsc = true;
        }
        var thead = byId('orders-thead');
        if (thead) {
            var ths = thead.querySelectorAll('th');
            for (var i = 0; i < ths.length; i++) {
                var th = ths[i];
                var icon = th.querySelector('i');
                if (!icon) continue;
                var onclick = th.getAttribute('onclick') || '';
                var match = onclick.match(/'([^']+)'/);
                if (match && match[1] === field) {
                    icon.className = 'fa-solid ' + (sortAsc ? 'fa-sort-up' : 'fa-sort-down');
                } else {
                    icon.className = 'fa-solid fa-sort';
                }
            }
        }
        _applyFilters();
    }

    // ========== عرض الجدول ==========
    function _renderTable(data) {
        var tbody = byId('orders-table-body');
        if (!tbody) return;

        if (!data || data.length === 0) {
            safeHTML(tbody, '<tr><td colspan="9" class="text-center py-8 text-gray-500">لا توجد أوردرات</td></tr>');
            var pc = byId('orders-table-body-controls');
            if (pc) safeHTML(pc, '');
            return;
        }

        var checkAll = byId('check-all');
        if (checkAll) checkAll.checked = false;

        RW_Table.paginate('orders-table-body', data, 1, 50, function(o) {
            var sc = '';
            if (o.order_status === 'Draft') sc = 'bg-yellow-100 text-yellow-700';
            else if (o.order_status === 'Confirmed') sc = 'bg-blue-100 text-blue-700';
            else if (o.order_status === 'Pending') sc = 'bg-purple-100 text-purple-700';
            else if (o.order_status === 'Invoiced' || o.order_status === 'Delivered') sc = 'bg-green-100 text-green-700';
            else if (o.order_status === 'Returned') sc = 'bg-orange-100 text-orange-700';
            else if (o.order_status === 'Cancelled') sc = 'bg-red-100 text-red-700';
            else sc = 'bg-gray-100 text-gray-700';
            var actions = '';
            if (o.order_status === 'Draft') {
                actions += '<button onclick="event.stopPropagation();RW_Orders._confirm(\'' + o.order_code + '\')" class="text-green-600 mx-1" title="تأكيد"><i class="fa-solid fa-check-circle"></i></button>';
            }
            // ✅ تعديل: إضافة Invoiced للحالات التي يمكن حذفها (طالما لا يوجد runsheet_id)
			console.log('DEBUG_DELETE:', o.order_code, o.order_status, o.runsheet_id);
var canDelete = (o.order_status === 'Draft' || o.order_status === 'Confirmed' || o.order_status === 'Invoiced') && !o.runsheet_id;
if (canDelete) {
    actions += '<button onclick="event.stopPropagation();RW_Orders._delete(\'' + o.order_code + '\')" class="text-red-500 mx-1" title="حذف"><i class="fa-solid fa-trash-can"></i></button>';
}
            return '<tr class="border-b hover:bg-gray-50 cursor-pointer" onclick="RW_Orders._showDetails(\'' + o.order_code + '\')">' +
                '<td class="p-3 text-center" onclick="event.stopPropagation()"><input type="checkbox" class="order-checkbox" data-id="' + o.order_code + '"></td>' +
                '<td class="p-3 text-center font-bold text-blue-600">' + (o.order_code || '') + '</td>' +
                '<td class="p-3 text-center">' + (o.order_date ? new Date(o.order_date).toLocaleDateString('ar-EG') : '') + '</td>' +
                '<td class="p-3 text-center"><p class="font-semibold">' + (o.customer_name || '') + '</p><p class="text-xs text-gray-500">' + (o.area || '') + '</p></td>' +
                '<td class="p-3 text-center font-bold">' + (o.itemsCount || 0) + '</td>' +
                '<td class="p-3 text-center font-bold">' + Number(o.total_amount || 0).toLocaleString() + ' EGP</td>' +
                '<td class="p-3 text-center"><span class="px-2 py-1 rounded-full text-xs font-semibold ' + sc + '">' + (o.order_status || '') + '</span></td>' +
                '<td class="p-3 text-center">' + (o._runsheetCode || '---') + '</td>' +
                '<td class="p-3 text-center">' + actions + '</td>' +
            '</tr>';
        });
    }

    // ========== الإجراءات الأساسية ==========
    function _getSelectedOrders() {
        var selected = [];
        document.querySelectorAll('.order-checkbox:checked').forEach(function(cb) {
            selected.push(cb.dataset.id);
        });
        return selected;
    }

    function _confirm(code) {
        Swal.fire({
            title: 'تأكيد الأوردر',
            text: 'تحويل ' + code + ' إلى مؤكد؟',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'تأكيد',
            cancelButtonText: 'إلغاء'
        }).then(function(cf) {
            if (!cf.isConfirmed) return;
            showLoader('جاري التأكيد...');
            supabase.auth.getSession().then(function(ses) {
                var t = ses.data.session && ses.data.session.access_token;
                return fetch(RW_SUPABASE_URL + '/functions/v1/confirm-order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t },
                    body: JSON.stringify({ order_code: code })
                }).then(function(res) { return res.json(); });
            }).then(function(json) {
                hideLoader();
                if (json.success) {
                    var found = ordersData.find(function(o) { return o.order_code === code; });
                    if (found) {
                        var oldStatus = found.order_status;
                        found.order_status = 'Confirmed';
                        RW_Audit_log('update', 'orders', code, { order_status: oldStatus }, { order_status: 'Confirmed' });
                        RW_Workflow.evaluate('orders', 'update', code, { order_status: 'Confirmed', order_code: code });
                        RW_Notification.send('order_confirmed', { order_code: code, customer_name: found.customer_name || '', table: 'orders', id: code }, RW_STATE.app.currentUser.email);
                    }
                    showToast('تم التأكيد', 'success');
                    _applyFilters();
                } else showToast(json.msg || 'فشل', 'error');
            }).catch(function(e) { hideLoader(); showToast('فشل الاتصال', 'error'); });
        });
    }

function _delete(code) {
    Swal.fire({
        title: 'تأكيد الحذف',
        text: 'حذف الأوردر ' + code + ' نهائياً؟ لا يمكن التراجع.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        confirmButtonText: 'نعم، احذف',
        cancelButtonText: 'تراجع'
    }).then(function(cf) {
        if (!cf.isConfirmed) return;
        showLoader('جاري الحذف...');
        supabase.auth.getSession().then(function(ses) {
            var t = ses.data.session && ses.data.session.access_token;
            return fetch(RW_SUPABASE_URL + '/functions/v1/delete-order', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t },
                body: JSON.stringify({ order_code: code })
            }).then(function(res) { return res.json(); });
        }).then(function(json) {
            hideLoader();
            if (json.success) {
                var found = ordersData.find(function(o) { return o.order_code === code; });
                if (found) {
                    RW_Audit_log('delete', 'orders', code, found, null);
                }
                showToast('تم الحذف', 'success');
                _refreshData();
            } else {
                showToast(json.msg || 'فشل', 'error');
            }
        }).catch(function(e) { hideLoader(); showToast('فشل الاتصال', 'error'); });
    });
}
	
function _confirmOrderFromDetails(code) {
    Swal.fire({
        title: 'تأكيد الأوردر',
        text: 'سيتم تحويل الأوردر ' + code + ' إلى مؤكد. متابعة؟',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'نعم، أكّد',
        cancelButtonText: 'إلغاء'
    }).then(function(confirmResult) {
        if (!confirmResult.isConfirmed) return;

        showLoader('جاري تأكيد الأوردر...');

        supabase.auth.getSession().then(function(sessionRes) {
            var token = null;
            if (sessionRes && sessionRes.data && sessionRes.data.session) {
                token = sessionRes.data.session.access_token;
            }
            if (!token) {
                hideLoader();
                showToast('انتهت الجلسة. يرجى إعادة تسجيل الدخول.', 'error');
                return;
            }

            return fetch(RW_SUPABASE_URL + '/functions/v1/confirm-order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({ order_code: code })
            }).then(function(res) { return res.json(); });
        }).then(function(json) {
            hideLoader();
            if (json && json.success) {
                // ✅ تحديث بيانات الأوردر في الذاكرة
                var found = null;
                if (typeof ordersData !== 'undefined' && ordersData) {
                    for (var i = 0; i < ordersData.length; i++) {
                        if (ordersData[i].order_code === code) {
                            found = ordersData[i];
                            break;
                        }
                    }
                }
                if (found) {
                    var oldStatus = found.order_status;
                    found.order_status = 'Confirmed';
                    // ✅ إعادة حساب itemsCount لهذا الأوردر
                    supabase.from('order_details').select('id', { count: 'exact', head: true }).eq('order_id', found.id).then(function(countRes) {
                        if (countRes && countRes.count !== undefined) {
                            found.itemsCount = countRes.count;
                        }
                    });
                    if (typeof RW_Audit_log === 'function') {
                        RW_Audit_log('update', 'orders', code, { order_status: oldStatus }, { order_status: 'Confirmed' });
                    }
                }

                showToast('تم تأكيد الأوردر بنجاح', 'success');

                if (typeof _applyFilters === 'function') {
                    _applyFilters();
                }

                _showDetails(code);
            } else {
                showToast((json && json.msg) || 'فشل تأكيد الأوردر', 'error');
            }
        }).catch(function(e) {
            hideLoader();
            showToast('فشل الاتصال بـ Edge Function', 'error');
            console.error(e);
        });
    });
}
	
    // ========== مودال التفاصيل ==========
function _showDetails(code) {
    showLoader('جاري تحميل التفاصيل...');
    supabase.from('orders').select('*').eq('order_code', code).maybeSingle().then(function(oRes) {
        var order = oRes.data;
        if (!order) { hideLoader(); showToast('الأوردر غير موجود', 'error'); return; }

        return supabase.from('order_details').select('*').eq('order_id', order.id).then(function(itemsRes) {
            var items = itemsRes.data || [];
            hideLoader();

            var warningHtml = '';
            if (order.runsheet_id) {
                warningHtml = '<div class="bg-amber-50 border-r-4 border-amber-500 p-3 mb-4 rounded">' +
                    '<p class="text-amber-700 text-sm"><i class="fa-solid fa-link ml-2"></i> مرتبط بالرانشيت: <strong>' + esc(order.runsheet_id) + '</strong></p></div>';
            }

            var itemsHtml = '';
            var itemsTotal = 0;
            if (items.length > 0) {
                itemsHtml = '<table class="w-full border text-sm"><thead class="bg-gray-100"><tr>' +
                    '<th class="p-2">الصنف</th><th class="p-2 text-center">الوحدة</th><th class="p-2 text-center">الكمية</th>' +
                    '<th class="p-2 text-center">السعر</th><th class="p-2 text-center">الإجمالي</th></tr></thead><tbody>';
                for (var i = 0; i < items.length; i++) {
                    var it = items[i];
                    var lt = Number(it.line_amount) || (Number(it.qty) * Number(it.unit_price));
                    itemsTotal += lt;
                    itemsHtml += '<tr><td class="p-2 font-semibold">' + (it.item_name || '') + '</td>' +
                        '<td class="p-2 text-center">' + (it.unit || 'حبة') + '</td>' +
                        '<td class="p-2 text-center">' + it.qty + '</td>' +
                        '<td class="p-2 text-center">' + Number(it.unit_price).toLocaleString() + '</td>' +
                        '<td class="p-2 text-center font-bold">' + lt.toLocaleString() + '</td></tr>';
                }
                itemsHtml += '</tbody></table>';
            } else {
                itemsHtml = '<div class="text-center py-4 text-gray-500">لا توجد أصناف مسجلة لهذا الأوردر</div>';
            }

            var deliveryFee = Number(order.delivery_fee) || 0;
            var grandTotal = itemsTotal + deliveryFee;

            var actionButtons = '';

            // ✅ زر تأكيد الأوردر – يظهر لـ Draft أو Pending غير المرتبطة برانشيت
            if ((order.order_status === 'Draft' || order.order_status === 'Pending') && !order.runsheet_id) {
                actionButtons += '<button id="btn-confirm-order-modal" class="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold shadow"><i class="fa-solid fa-check-circle ml-2"></i> تأكيد الأوردر</button>';
            }

            // ✅ زر حذف الأوردر – يظهر لـ Draft، Pending، Confirmed غير المرتبطة برانشيت
            // ✅ تعديل: إضافة Invoiced واستبعاد Returned/Partially Returned
var cannotDeleteStatuses = ['Returned', 'Partially Returned', 'Cancelled'];
var isDeletable = (order.order_status === 'Draft' || order.order_status === 'Pending' || order.order_status === 'Confirmed' || order.order_status === 'Invoiced');
var canDelete = isDeletable && !order.runsheet_id && cannotDeleteStatuses.indexOf(order.order_status) === -1;
if (canDelete) {
    actionButtons += '<button id="btn-delete-order-modal" class="bg-red-600 text-white px-6 py-2 rounded-xl font-bold shadow"><i class="fa-solid fa-trash ml-2"></i> حذف الأوردر</button>';
}

            // ✅ زر طباعة الفاتورة – يظهر دائماً
            actionButtons += '<button id="btn-print-order-modal" class="bg-emerald-600 text-white px-6 py-2 rounded-xl font-bold shadow"><i class="fa-solid fa-print ml-2"></i> طباعة الفاتورة</button>';

            var html = '<div class="text-right">' + warningHtml +
                '<div class="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-2xl mb-4">' +
                    '<div><p><b>العميل:</b> ' + esc(order.customer_name || '') + '</p><p><b>المنطقة:</b> ' + esc(order.area || '') + '</p></div>' +
                    '<div><p><b>الحالة:</b> <span class="font-bold">' + esc(order.order_status || '') + '</span></p><p><b>الرانشيت:</b> ' + (order.runsheet_id || '---') + '</p></div>' +
                '</div>' +
                '<div class="overflow-x-auto">' + itemsHtml + '</div>' +
                '<div class="bg-gray-50 p-4 rounded-2xl mt-4">' +
                    '<div class="flex justify-between mb-2"><span>مجموع الأصناف:</span><span>' + Number(itemsTotal).toLocaleString() + ' EGP</span></div>' +
                    '<div class="flex justify-between mb-2"><span class="text-blue-600">رسوم التوصيل:</span><span class="text-blue-600">' + Number(deliveryFee).toLocaleString() + ' EGP</span></div>' +
                    '<div class="flex justify-between pt-2 border-t"><span class="font-bold">الإجمالي:</span><span class="font-bold text-emerald-600 text-lg">' + Number(grandTotal).toLocaleString() + ' EGP</span></div>' +
                '</div>' +
                '<div class="flex justify-center gap-3 mt-6 pt-4 border-t">' +
                    actionButtons +
                '</div>' +
            '</div>';

            Swal.fire({
                title: 'تفاصيل الأوردر: ' + code,
                html: html,
                width: '900px',
                showCloseButton: true,
                showConfirmButton: false,
                showCancelButton: true,
                cancelButtonText: 'إغلاق',
                didOpen: function() {
                    var confirmBtn = document.getElementById('btn-confirm-order-modal');
                    if (confirmBtn) {
                        confirmBtn.onclick = function() {
                            Swal.close();
                            _confirmOrderFromDetails(code);
                        };
                    }

                    var deleteBtn = document.getElementById('btn-delete-order-modal');
                    if (deleteBtn) {
                        deleteBtn.onclick = function() { Swal.close(); _delete(code); };
                    }

                    var printBtn = document.getElementById('btn-print-order-modal');
                    if (printBtn) {
                        printBtn.onclick = function() { _printOrder(code); };
                    }
                }
            });
        });
    }).catch(function(e) { hideLoader(); showToast('فشل التحميل', 'error'); console.error(e); });
}
    function _printOrder(code) {
        showLoader('جاري تحضير الطباعة...');
        
        var order = null;
        var items = [];
        var settings = {};
        
        supabase.from('orders').select('*').eq('order_code', code).maybeSingle()
            .then(function(oRes) {
                order = oRes.data;
                if (!order) throw new Error('ORDER_NOT_FOUND');
                return supabase.from('order_details').select('*').eq('order_id', order.id);
            })
            .then(function(itRes) {
                items = itRes.data || [];
                return supabase.from('app_settings').select('*').limit(1).single();
            })
            .then(function(sRes) {
                if (sRes.data) settings = sRes.data;
                _buildPrintWindow(order, items, settings);
            })
            .catch(function(err) {
                console.error('Print error:', err);
                if (order) {
                    _buildPrintWindow(order, items, {});
                } else {
                    hideLoader();
                    showToast('الأوردر غير موجود', 'error');
                }
            });
    }
    
    function _buildPrintWindow(order, items, settings) {
        hideLoader();
        
        var companyName = settings.company_name || 'الروائع';
        var taxRate = Number(settings.tax_rate) || 0;
        var vatNumber = settings.vat_number || '310000000000003';
        var registeredName = settings.registered_name || companyName;
        var businessAddress = settings.business_address || '';

        var printWindow = window.open('', '_blank');
        if (!printWindow) { showToast('الرجاء السماح للنوافذ المنبثقة', 'warning'); return; }

        var itemsHtml = '', itemsTotal = 0;
        for (var i = 0; i < items.length; i++) {
            var it = items[i];
            var lt = Number(it.line_amount) || (Number(it.qty) * Number(it.unit_price));
            itemsTotal += lt;
            itemsHtml += '<tr><td class="border p-2">' + esc(it.item_name) + '</td>' +
                '<td class="border p-2 text-center">' + (it.unit || 'حبة') + '</td>' +
                '<td class="border p-2 text-center">' + it.qty + '</td>' +
                '<td class="border p-2 text-center">' + Number(it.unit_price).toLocaleString() + '</td>' +
                '<td class="border p-2 text-center">' + lt.toLocaleString() + '</td></tr>';
        }

        var deliveryFee = Number(order.delivery_fee) || 0;
        var grandTotal = itemsTotal + deliveryFee;
        var beforeTax = itemsTotal + deliveryFee;
        var taxAmount = Math.round(beforeTax * taxRate) / 100;

        var invoiceDate = order.order_date ? new Date(order.order_date).toISOString() : new Date().toISOString();
        var qrBase64 = generateQRInvoiceBase64(registeredName, vatNumber, invoiceDate, String(grandTotal), String(taxAmount));

        var html = '<!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8"><title>فاتورة ' + esc(order.order_code) + '</title>' +
            '<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"><\/script>' +
            '<style>body{font-family:"Cairo",sans-serif;padding:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px;text-align:right}th{background:#f2f2f2}</style></head>' +
            '<body><div style="text-align:center;border-bottom:2px solid #000;padding-bottom:10px"><h1>فاتورة بيع</h1><p>رقم: ' + esc(order.order_code) + '</p><p>التاريخ: ' + (order.order_date ? new Date(order.order_date).toLocaleDateString('ar-EG') : '') + '</p></div>' +
            '<p><strong>البائع:</strong> ' + esc(registeredName) + ' | <strong>رقم ضريبي:</strong> ' + esc(vatNumber) + '</p>' +
            '<p><strong>العميل:</strong> ' + esc(order.customer_name || '') + '</p><p><strong>المنطقة:</strong> ' + esc(order.area || '') + '</p>' +
            '<table><thead><tr><th>الصنف</th><th>الوحدة</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>' + itemsHtml + '</tbody></table>' +
            '<div style="font-weight:bold;font-size:18px;margin-top:20px">الإجمالي: ' + Number(order.total_amount || 0).toLocaleString() + ' EGP</div>' +
            '<div style="text-align:center;margin-top:20px;padding-top:15px;border-top:1px dashed #ccc;"><p style="font-weight:bold">رمز الفاتورة الإلكترونية</p><div id="print-qrcode-container" style="display:inline-block;"></div><p style="font-size:11px;color:#888">امسح الكود للتحقق من الفاتورة</p></div>' +
            '<script>window.onload=function(){try{var c=document.getElementById("print-qrcode-container");if(c&&typeof QRCode!=="undefined"){c.innerHTML="";new QRCode(c,{text:"' + qrBase64 + '",width:150,height:150,colorDark:"#000000",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.M});}}catch(e){}window.print();};<\/script></body></html>';
        printWindow.document.write(html);
        printWindow.document.close();
    }

    // ========== إنشاء وضم الرانشيتات ==========
    async function _createRS() {
        var selected = _getSelectedOrders();
        if (!selected.length) { showToast('اختر أوردراً واحداً على الأقل', 'warning'); return; }
        var cf = await Swal.fire({
            title: 'إنشاء رانشيت جديد',
            text: 'سيتم تجميع ' + selected.length + ' أوردر في رانشيت جديد. متابعة؟',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'نعم، إنشاء',
            cancelButtonText: 'إلغاء'
        });
        if (!cf.isConfirmed) return;
        showLoader('جاري إنشاء الرانشيت...');

        var ses = await supabase.auth.getSession();
        var t = (ses && ses.data && ses.data.session) ? ses.data.session.access_token : null;
        if (!t) {
            hideLoader();
            showToast('انتهت الجلسة. يرجى إعادة تسجيل الدخول.', 'error');
            return;
        }

        try {
            await supabase
                .from('orders')
                .update({ runsheet_id: null, order_status: 'Confirmed' })
                .in('order_code', selected);

            var res = await fetch(RW_SUPABASE_URL + '/functions/v1/create-runsheet', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t },
                body: JSON.stringify({ selectedOrders: selected })
            });
            var json = await res.json();
            hideLoader();
            if (json.success) {
                showToast('تم إنشاء الرانشيت: ' + json.rsId, 'success');
                var newRsRes = await supabase.from('runsheets').select('id').eq('runsheet_code', json.rsId).maybeSingle();
                var rsUuid = (newRsRes && newRsRes.data) ? newRsRes.data.id : json.rsId;
                for (var i = 0; i < ordersData.length; i++) {
                    if (selected.indexOf(ordersData[i].order_code) !== -1) {
                        ordersData[i].runsheet_id = rsUuid;
                        ordersData[i].order_status = 'Pending';
                    }
                }
                await _loadRunsheetCodes(); _applyFilters();
            } else {
                showToast(json.msg || 'فشل', 'error');
            }
        } catch(e) {
            hideLoader();
            showToast('فشل الاتصال', 'error');
        }
    }

    async function _appendRS() {
        var selected = _getSelectedOrders();
        if (!selected.length) { showToast('اختر أوردراً واحداً على الأقل', 'warning'); return; }
        try {
            var rsRes = await supabase.from('runsheets').select('runsheet_code, status').in('status', ['Open', 'Confirmed']);
            if (!rsRes.data || !rsRes.data.length) { showToast('لا توجد رانشيتات مفتوحة', 'info'); return; }
            var opts = {};
            rsRes.data.forEach(function(rs) { opts[rs.runsheet_code] = rs.runsheet_code + ' - ' + rs.status; });
            var v = await Swal.fire({
                title: 'اختر الرانشيت',
                input: 'select',
                inputOptions: opts,
                showCancelButton: true,
                confirmButtonText: 'ضم',
                cancelButtonText: 'إلغاء'
            });
            if (!v.value) return;

            var ses = await supabase.auth.getSession();
            var t = (ses && ses.data && ses.data.session) ? ses.data.session.access_token : null;
            if (!t) {
                hideLoader();
                showToast('انتهت الجلسة. يرجى إعادة تسجيل الدخول.', 'error');
                return;
            }

            showLoader('جاري الضم...');
            var res = await fetch(RW_SUPABASE_URL + '/functions/v1/append-to-runsheet', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t },
                body: JSON.stringify({ targetRSID: v.value, selectedOrders: selected })
            });
            var json = await res.json(); hideLoader();
            if (json.success) {
                showToast('تم الضم', 'success');
                var targetRsRes = await supabase.from('runsheets').select('id').eq('runsheet_code', v.value).maybeSingle();
                var rsUuid = (targetRsRes && targetRsRes.data) ? targetRsRes.data.id : v.value;
                for (var i = 0; i < ordersData.length; i++) {
                    if (selected.indexOf(ordersData[i].order_code) !== -1) {
                        ordersData[i].runsheet_id = rsUuid;
                        ordersData[i].order_status = 'Pending';
                    }
                }
                await _loadRunsheetCodes(); _applyFilters();
            } else showToast(json.msg || 'فشل', 'error');
        } catch(e) { hideLoader(); showToast('فشل الاتصال', 'error'); }
    }

function _loadRunsheetCodes() {
    return supabase.from('runsheets').select('id, runsheet_code').then(function(res) {
        var map = {};
        var data = res.data || [];
        for (var i = 0; i < data.length; i++) {
            map[data[i].id] = data[i].runsheet_code;
        }
        for (var j = 0; j < ordersData.length; j++) {
            var rsId = ordersData[j].runsheet_id;
            if (rsId && map[rsId]) {
                ordersData[j]._runsheetCode = map[rsId];
            } else {
                ordersData[j]._runsheetCode = null;
            }
        }
        // ✅ هذا السطر هو الحل – كان موجوداً في النسخة الانتقالية
        _applyFilters();
    }).catch(function(e) {
        console.error('فشل تحميل أكواد الرانشيتات:', e);
        // حتى لو فشلت، نعرض البيانات بدون أكواد الرانشيت
        _applyFilters();
    });
}

async function _refreshData() {
    var ordRes = await supabase.from('orders').select('*, runsheets(runsheet_code)');
    ordersData = (ordRes.data || []).map(function(o) {
        if (o.runsheets && o.runsheets.runsheet_code) {
            o._runsheetCode = o.runsheets.runsheet_code;
        } else {
            o._runsheetCode = null;
        }
        return o;
    });
    var detRes = await supabase.from('order_details').select('order_id, item_code');
    var details = detRes.data || [];
    var itemsCountMap = {};
    for (var i = 0; i < details.length; i++) {
        var oid = details[i].order_id;
        if (oid) itemsCountMap[oid] = (itemsCountMap[oid] || 0) + 1;
    }
    for (var j = 0; j < ordersData.length; j++) {
        // ✅ التصحيح الوحيد: استخدام ordersData[j].id بدلاً من ordersData[j].order_code
        ordersData[j].itemsCount = itemsCountMap[ordersData[j].id] || 0;
    }
    _applyFilters();
}
    return {
        render: render,
        _applyFilters: _applyFilters,
        _resetFilters: _resetFilters,
        _showWithoutRS: _showWithoutRS,
        _sort: _sort,
        _confirm: _confirm,
        _delete: _delete,
        _showDetails: _showDetails,
        _createRS: _createRS,
        _appendRS: _appendRS,
        _refreshData: _refreshData
    };
})();
window.RW_Orders = RW_Orders;
// ============================================================
// RW_Runsheets – الرانشيتات (النسخة النهائية المُصلحة - بدون عمود إجراءات)
// ============================================================
var RW_Runsheets = (function() {
    var sortField = 'runsheet_code';
    var sortAsc = true;
    var data = [];
    var driversCache = [];
    var vehiclesCache = [];

    function _esc(s) { return String(s||'').replace(/[&<>]/g, function(m) { return m==='&'?'&amp;':m==='<'?'&lt;':'&gt;'; }); }
    function _fmtNum(n) { return Number(n || 0).toLocaleString(); }

    async function loadHelpers() {
        try {
            var dRes = await supabase.from('users').select('email, name').in('role', ['driver','سائق','مندوب']);
            driversCache = dRes.data || [];
            var vRes = await supabase.from('vehicles').select('id, license_plate, model');
            vehiclesCache = vRes.data || [];
        } catch(e) { console.error(e); }
    }

    async function render() {
        var c = byId('rw-page-container');
        if (!c) return;
        safeText(byId('rw-header-title'), 'الرانشيتات');
        
        await loadHelpers();
        var res = await supabase.from('runsheets').select('*').order('run_date', { ascending: false });
        data = res.data || [];

        // واجهة التبويب (بدون عمود إجراءات)
        var html = '<div class="p-4">' +
            '<div class="bg-white rounded-2xl shadow-sm border p-4 mb-4">' +
                '<div class="grid grid-cols-2 md:grid-cols-6 gap-2">' +
                    '<input type="text" id="rs-f-id" placeholder="رقم الرانشيت..." class="p-2 bg-gray-50 rounded text-sm" oninput="RW_Runsheets._apply()">' +
                    '<select id="rs-f-status" class="p-2 bg-gray-50 rounded text-sm" onchange="RW_Runsheets._apply()">' +
                        '<option value="">كل الحالات</option>' +
                        '<option>Open</option><option>Picking</option><option>Picked</option>' +
                        '<option>Loading</option><option>Loaded</option><option>Delivering</option>' +
                        '<option>Delivered</option><option>Returning</option><option>Returned</option>' +
                        '<option>Cancelled</option>' +
                    '</select>' +
                    '<input type="text" id="rs-f-driver" placeholder="السائق..." class="p-2 bg-gray-50 rounded text-sm" oninput="RW_Runsheets._apply()">' +
                    '<input type="date" id="rs-f-from" class="p-2 bg-gray-50 rounded text-sm" onchange="RW_Runsheets._apply()">' +
                    '<input type="date" id="rs-f-to" class="p-2 bg-gray-50 rounded text-sm" onchange="RW_Runsheets._apply()">' +
                    '<button onclick="RW_Runsheets._apply()" class="bg-gray-600 text-white px-3 rounded text-sm">تطبيق</button>' +
                '</div>' +
            '</div>' +
            '<div class="bg-white rounded-2xl shadow-sm border overflow-auto" style="max-height:65vh">' +
                '<table class="w-full min-w-[1200px]">' +
                    '<thead class="bg-gray-50 sticky top-0 z-10">' +
                        '<tr>' +
                            '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Runsheets._sort(\'runsheet_code\')">رقم الرانشيت <i class="fa-solid fa-sort"></i></th>' +
                            '<th class="p-3 text-center text-xs font-bold uppercase">التاريخ</th>' +
                            '<th class="p-3 text-center text-xs font-bold uppercase">السائق</th>' +
                            '<th class="p-3 text-center text-xs font-bold uppercase">السيارة</th>' +
                            '<th class="p-3 text-center cursor-pointer text-xs font-bold uppercase" onclick="RW_Runsheets._sort(\'total_amount\')">القيمة <i class="fa-solid fa-sort"></i></th>' +
                            '<th class="p-3 text-center text-xs font-bold uppercase">الحالة</th>' +
                        '</tr>' +
                    '</thead>' +
                    '<tbody id="rs-table-body"><tr><td colspan="6" class="text-center py-8">جاري التحميل...</td></tr></tbody>' +
                '</table>' +
            '</div>' +
        '</div>';
        safeHTML(c, html);
        _apply();
    }

    function _apply() {
        var filtered = data.slice();
        var idEl = byId('rs-f-id'), stEl = byId('rs-f-status'), drEl = byId('rs-f-driver'), fromEl = byId('rs-f-from'), toEl = byId('rs-f-to');
        var id = idEl ? idEl.value.toLowerCase() : '';
        var st = stEl ? stEl.value : '';
        var dr = drEl ? drEl.value.toLowerCase() : '';
        var fd = fromEl ? fromEl.value : '';
        var td = toEl ? toEl.value : '';

        if (id) filtered = filtered.filter(function(r) { return (r.runsheet_code||'').toLowerCase().indexOf(id) !== -1; });
        if (st) filtered = filtered.filter(function(r) { return r.status === st; });
        if (dr) filtered = filtered.filter(function(r) { return (r.driver_id||'').toLowerCase().indexOf(dr) !== -1; });
        if (fd) filtered = filtered.filter(function(r) { return r.run_date >= fd; });
        if (td) filtered = filtered.filter(function(r) { return r.run_date <= td; });

        var sorted = filtered.sort(function(a,b) {
            var va = a[sortField]||'', vb = b[sortField]||'';
            if (sortField === 'total_amount') { va = Number(va); vb = Number(vb); }
            else if (sortField === 'run_date') { va = new Date(va); vb = new Date(vb); }
            else { va = String(va).toLowerCase(); vb = String(vb).toLowerCase(); }
            return (va < vb ? -1 : va > vb ? 1 : 0) * (sortAsc ? 1 : -1);
        });
        _renderTable(sorted);
    }

    function _sort(field) {
        if (sortField === field) sortAsc = !sortAsc;
        else { sortField = field; sortAsc = true; }
        _apply();
    }

    function _statusClass(st) {
        if (st === 'Open' || st === 'Confirmed') return 'bg-blue-100 text-blue-700';
        if (st === 'Picking' || st === 'Picked') return 'bg-purple-100 text-purple-700';
        if (st === 'Loading' || st === 'Loaded') return 'bg-orange-100 text-orange-700';
        if (st === 'Delivering') return 'bg-cyan-100 text-cyan-700';
        if (st === 'Delivered') return 'bg-green-100 text-green-700';
        if (st === 'Returning' || st === 'Returned') return 'bg-yellow-100 text-yellow-700';
        if (st === 'Cancelled') return 'bg-red-100 text-red-700';
        return 'bg-gray-100 text-gray-600';
    }

    function _renderTable(d) {
        var tb = byId('rs-table-body');
        if (!tb) return;
        if (!d.length) {
            safeHTML(tb, '<tr><td colspan="6" class="text-center py-8">لا توجد رانشيتات</td></tr>');
            return;
        }
        RW_Table.paginate('rs-table-body', d, 1, 50, function(r) {
            var driverName = r.driver_id || '---';
            for (var i = 0; i < driversCache.length; i++) {
                if (driversCache[i].email === r.driver_id) { driverName = driversCache[i].name; break; }
            }
            var vehiclePlate = r.vehicle_id || '---';
            for (var j = 0; j < vehiclesCache.length; j++) {
                if (vehiclesCache[j].id === r.vehicle_id) { vehiclePlate = vehiclesCache[j].license_plate; break; }
            }
            return '<tr class="border-b hover:bg-gray-50 cursor-pointer" onclick="RW_Runsheets._details(\'' + r.runsheet_code + '\')">' +
                '<td class="p-3 text-center font-bold text-emerald-600">' + (r.runsheet_code||'') + '</td>' +
                '<td class="p-3 text-center">' + (r.run_date ? new Date(r.run_date).toLocaleDateString('ar-EG') : '') + '</td>' +
                '<td class="p-3 text-center">' + driverName + '</td>' +
                '<td class="p-3 text-center">' + vehiclePlate + '</td>' +
                '<td class="p-3 text-center font-bold">' + _fmtNum(r.total_amount) + ' EGP</td>' +
                '<td class="p-3 text-center"><span class="px-2 py-1 rounded-full text-xs ' + _statusClass(r.status) + '">' + (r.status||'') + '</span></td>' +
            '</tr>';
        });
    }

    // ========== مودال التفاصيل (مع جميع الإجراءات) ==========
async function _details(code) {
    showLoader('جاري تحميل تفاصيل الرانشيت...');
    try {
        var rsRes = await supabase.from('runsheets').select('*').eq('runsheet_code', code).maybeSingle();
        var rs = rsRes.data;
        if (!rs) { hideLoader(); showToast('الرانشيت غير موجود', 'error'); return; }

        var ordersRes = await supabase.from('orders').select('order_code, customer_name, total_amount').eq('runsheet_id', rs.id);
        var orders = ordersRes.data || [];

        var itemsRes = await supabase.from('run_sheet_details').select('*').eq('runsheet_id', rs.id);
        var items = itemsRes.data || [];

        hideLoader();

        // بناء خيارات السائقين والمركبات
        var driverOptions = '<option value="">اختر السائق...</option>';
        for (var i = 0; i < driversCache.length; i++) {
            var d = driversCache[i];
            var sel = (rs.driver_id === d.email) ? ' selected' : '';
            driverOptions += '<option value="' + d.email + '"' + sel + '>' + d.name + ' (' + d.email + ')</option>';
        }
        var vehicleOptions = '<option value="">اختر المركبة...</option>';
        for (var j = 0; j < vehiclesCache.length; j++) {
            var v = vehiclesCache[j];
            var sel = (rs.vehicle_id === v.id) ? ' selected' : '';
            vehicleOptions += '<option value="' + v.id + '"' + sel + '>' + v.license_plate + ' - ' + (v.model || '') + '</option>';
        }

        // بناء Badges الأوردرات
        var ordersHtml = '';
        if (orders.length > 0) {
            ordersHtml = '<div class="mb-4"><h4 class="font-bold text-lg mb-2">الأوردرات المرتبطة</h4><div class="bg-gray-50 rounded-lg p-3 flex flex-wrap gap-2">';
            for (var o = 0; o < orders.length; o++) {
                ordersHtml += '<span class="inline-block bg-white rounded px-3 py-1 text-sm shadow-sm">' + orders[o].order_code + ' - ' + orders[o].customer_name + ' (' + _fmtNum(orders[o].total_amount) + ' EGP)</span>';
            }
            ordersHtml += '</div></div>';
        } else {
            ordersHtml = '<div class="mb-4 text-gray-500 text-sm">لا توجد أوردرات مرتبطة</div>';
        }

        // بناء جدول الأصناف مع Scroll
        var itemsHtml = '';
        var grandTotal = 0;
        if (items.length > 0) {
            itemsHtml = '<div class="mt-4"><h4 class="font-bold text-lg mb-2">الأصناف المجمعة</h4>';
            itemsHtml += '<div class="overflow-x-auto border rounded-lg" style="max-height:300px;overflow-y:auto;">';
            itemsHtml += '<table class="w-full text-sm"><thead class="bg-gray-100 sticky top-0 z-10"><tr>' +
                '<th class="p-2 border">الكود</th><th class="p-2 border">الصنف</th><th class="p-2 border text-center">الوحدة</th>' +
                '<th class="p-2 border text-center">الكمية</th><th class="p-2 border text-center">السعر</th><th class="p-2 border text-center">الإجمالي</th></tr></thead><tbody>';
            for (var it = 0; it < items.length; it++) {
                var item = items[it];
                var lineTotal = (Number(item.qty_ordered) || 0) * (Number(item.unit_price) || 0);
                grandTotal += lineTotal;
                itemsHtml += '<tr><td class="p-2 border">' + _esc(item.item_code) + '</td>' +
                    '<td class="p-2 border font-semibold">' + _esc(item.item_name) + '</td>' +
                    '<td class="p-2 border text-center">' + _esc(item.unit) + '</td>' +
                    '<td class="p-2 border text-center font-bold">' + (item.qty_ordered || 0) + '</td>' +
                    '<td class="p-2 border text-center">' + _fmtNum(item.unit_price) + '</td>' +
                    '<td class="p-2 border text-center font-bold">' + _fmtNum(lineTotal) + '</td></tr>';
            }
            itemsHtml += '</tbody></table></div>';
            itemsHtml += '<div class="mt-3 text-left font-bold text-lg">إجمالي الأصناف: ' + _fmtNum(grandTotal) + ' EGP</div>';
            itemsHtml += '</div>';
        } else {
            itemsHtml = '<div class="text-center py-8 text-gray-500 mt-4">لا توجد أصناف مجمعة في هذا الرانشيت بعد.</div>';
        }

        // تجميع المحتوى
        var content = '<div class="text-right space-y-4" style="max-height:70vh;overflow-y:auto;padding:8px;">' +
            '<div class="flex justify-between items-center">' +
                '<div><h3 class="font-black text-2xl">' + rs.runsheet_code + '</h3><p class="text-gray-500">التاريخ: ' + (rs.run_date || '') + '</p></div>' +
                '<div><span class="px-3 py-1 rounded-full text-xs font-bold ' + _statusClass(rs.status) + '">' + rs.status + '</span></div>' +
            '</div>' +
            '<div class="grid grid-cols-2 md:grid-cols-4 gap-3 bg-gray-50 p-4 rounded-2xl">' +
                '<div><p class="text-xs text-gray-400">السائق</p><select id="rs-driver-select" class="w-full p-2 border rounded-lg bg-white text-sm">' + driverOptions + '</select></div>' +
                '<div><p class="text-xs text-gray-400">السيارة</p><select id="rs-vehicle-select" class="w-full p-2 border rounded-lg bg-white text-sm">' + vehicleOptions + '</select></div>' +
                '<div><p class="text-xs text-gray-400">عدد الأوردرات</p><p class="font-bold text-xl">' + orders.length + '</p></div>' +
                '<div><p class="text-xs text-gray-400">القيمة الإجمالية</p><p class="font-bold text-xl text-emerald-600">' + _fmtNum(rs.total_amount) + ' EGP</p></div>' +
            '</div>' +
            ordersHtml +
            itemsHtml +
            '<div class="flex justify-center gap-3 mt-6 pt-4 border-t">' +
                '<button id="btn-delete-rs-modal" class="bg-red-600 text-white px-6 py-2 rounded-xl font-bold shadow"><i class="fa-solid fa-trash ml-2"></i> حذف الرانشيت</button>' +
            '</div>' +
            '</div>';

        Swal.fire({
            title: 'تفاصيل الرانشيت: ' + code,
            html: content,
            width: '1000px',
            showCloseButton: true,
            showConfirmButton: true,
            confirmButtonText: 'حفظ التغييرات',
            showCancelButton: true,
            cancelButtonText: 'إلغاء',
            showDenyButton: true,
            denyButtonText: '<i class="fa-solid fa-print ml-1"></i> طباعة',
            denyButtonColor: '#2563eb',
            preConfirm: function() {
                var newDriver = document.getElementById('rs-driver-select').value;
                var newVehicle = document.getElementById('rs-vehicle-select').value;
                showLoader('جاري تحديث الرانشيت...');
                return supabase.from('runsheets').update({
                    driver_id: newDriver || null,
                    vehicle_id: newVehicle || null,
                    status: 'Open'
                }).eq('id', rs.id).then(function() {
                    hideLoader();
                    rs.driver_id = newDriver;
                    rs.vehicle_id = newVehicle;
                    _apply();
                    showToast('تم تحديث الرانشيت', 'success');
                }).catch(function(e) {
                    hideLoader();
                    showToast('فشل التحديث: ' + e.message, 'error');
                });
            },
            didOpen: function() {
                // ✅ زر الطباعة
                var denyBtn = Swal.getDenyButton();
                if (denyBtn) {
                    denyBtn.onclick = function() {
                        _printManifest(code, rs, orders, items);
                    };
                }
                // ✅ زر الحذف الجديد
                var deleteBtn = document.getElementById('btn-delete-rs-modal');
                if (deleteBtn) {
                    deleteBtn.onclick = function() {
                        Swal.close();
                        _deleteRunsheet(code);
                    };
                }
            }
        });
    } catch(e) {
        hideLoader();
        showToast('فشل تحميل التفاصيل', 'error');
        console.error(e);
    }
}
    async function _deleteRunsheet(code) {
        var found = null;
        for (var i = 0; i < data.length; i++) {
            if (data[i].runsheet_code === code) { found = data[i]; break; }
        }
        if (!found) { showToast('الرانشيت غير موجود', 'error'); return; }

        var cf = await Swal.fire({
            title: 'تأكيد الحذف',
            text: 'سيتم حذف الرانشيت ' + code + ' وتحرير جميع الأوردرات المرتبطة. متابعة؟',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'نعم، احذف',
            cancelButtonText: 'تراجع',
            confirmButtonColor: '#dc2626'
        });
        if (!cf.isConfirmed) return;
        showLoader('جاري حذف الرانشيت...');
        try {
            var rsId = found.id;
            // 1. تحرير الأوردرات
            await supabase.from('orders').update({ order_status: 'Confirmed', runsheet_id: null }).eq('runsheet_id', rsId);
            // 2. حذف التفاصيل
            await supabase.from('run_sheet_details').delete().eq('runsheet_id', rsId);
            // 3. حذف الرانشيت
            await supabase.from('runsheets').delete().eq('id', rsId);

            // إزالة العنصر من المصفوفة المحلية
            var idx = data.indexOf(found);
            if (idx > -1) data.splice(idx, 1);

            hideLoader();
            _apply();
            showToast('تم حذف الرانشيت وتحرير الأوردرات بنجاح', 'success');
        } catch(e) {
            hideLoader();
            showToast('فشل الحذف: ' + (e.message || 'خطأ غير معروف'), 'error');
        }
    }
    async function _cancelRunsheet(code) {
        var found = null;
        for (var i = 0; i < data.length; i++) {
            if (data[i].runsheet_code === code) { found = data[i]; break; }
        }
        if (!found) { showToast('الرانشيت غير موجود', 'error'); return; }
        if (found.status !== 'Open' && found.status !== 'Confirmed') {
            showToast('لا يمكن إلغاء رانشيت في حالة: ' + found.status, 'error');
            return;
        }
        var cf = await Swal.fire({
            title: 'إلغاء الرانشيت',
            text: 'سيتم إلغاء الرانشيت ' + code + ' وتحرير جميع الأوردرات المرتبطة.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'نعم، إلغاء',
            cancelButtonText: 'تراجع',
            confirmButtonColor: '#dc2626'
        });
        if (!cf.isConfirmed) return;
        showLoader('جاري إلغاء الرانشيت...');
        var hasError = false, errMsg = '';
        try {
            var rsId = found.id;
            var r1 = await supabase.from('runsheets').update({ status: 'Cancelled' }).eq('id', rsId);
            if (r1.error) { hasError = true; errMsg = r1.error.message; }
            if (!hasError) {
                var r2 = await supabase.from('orders').update({ order_status: 'Confirmed', runsheet_id: null }).eq('runsheet_id', rsId);
                if (r2.error) { hasError = true; errMsg = r2.error.message; }
            }
            if (!hasError) {
                var r3 = await supabase.from('run_sheet_details').delete().eq('runsheet_id', rsId);
                if (r3.error) { hasError = true; errMsg = r3.error.message; }
            }
        } catch(e) {
            hasError = true;
            errMsg = e.message || 'خطأ غير معروف';
        }
        hideLoader();
        if (hasError) {
            showToast('فشل الإلغاء: ' + errMsg, 'error');
            return;
        }
        // إزالة العنصر من المصفوفة المحلية لضمان المزامنة الفورية
var idx = data.indexOf(found);
if (idx > -1) {
    data.splice(idx, 1);
}
        _apply();
        showToast('تم إلغاء الرانشيت وتحرير الأوردرات بنجاح', 'success');
    }

    function _changeStatus(code, funcName) {
        showLoader('جاري تحديث الحالة...');
        supabase.auth.getSession().then(function(ses) {
            var t = ses.data.session ? ses.data.session.access_token : null;
            return fetch(RW_SUPABASE_URL + '/functions/v1/' + funcName, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t },
                body: JSON.stringify({ runsheet_code: code })
            });
        }).then(function(res) { return res.json(); }).then(function(json) {
            hideLoader();
            if (json.success) {
                showToast('تم بنجاح', 'success');
                _apply();
            } else {
                showToast(json.msg || 'فشل', 'error');
            }
        }).catch(function(e) {
            hideLoader();
            showToast('فشل الاتصال', 'error');
        });
    }
    function _printManifest(code, rs, orders, items) {
    var printWindow = window.open('', '_blank');
    if (!printWindow) {
        showToast('الرجاء السماح بالنوافذ المنبثقة', 'warning');
        return;
    }

    var ordersHtml = '';
    if (orders.length > 0) {
        for (var o = 0; o < orders.length; o++) {
            ordersHtml += '<span style="display:inline-block;background:#fff;border-radius:8px;padding:4px 12px;margin:4px;font-size:13px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">' + orders[o].order_code + ' - ' + orders[o].customer_name + ' (' + _fmtNum(orders[o].total_amount) + ' EGP)</span>';
        }
    } else {
        ordersHtml = '<p>لا توجد أوردرات مرتبطة</p>';
    }

    var itemsHtml = '';
    var grandTotal = 0;
    if (items.length > 0) {
        itemsHtml = '<table style="width:100%;border-collapse:collapse;margin-top:16px;">' +
            '<thead><tr style="background:#f3f4f6;">' +
            '<th style="padding:10px;border:1px solid #ddd;text-align:right;">الكود</th>' +
            '<th style="padding:10px;border:1px solid #ddd;text-align:right;">الصنف</th>' +
            '<th style="padding:10px;border:1px solid #ddd;text-align:center;">الوحدة</th>' +
            '<th style="padding:10px;border:1px solid #ddd;text-align:center;">الكمية</th>' +
            '<th style="padding:10px;border:1px solid #ddd;text-align:center;">السعر</th>' +
            '<th style="padding:10px;border:1px solid #ddd;text-align:center;">الإجمالي</th>' +
            '</tr></thead><tbody>';
        for (var it = 0; it < items.length; it++) {
            var item = items[it];
            var lineTotal = (Number(item.qty_ordered) || 0) * (Number(item.unit_price) || 0);
            grandTotal += lineTotal;
            itemsHtml += '<tr>' +
                '<td style="padding:8px;border:1px solid #ddd;">' + (item.item_code || '') + '</td>' +
                '<td style="padding:8px;border:1px solid #ddd;font-weight:bold;">' + (item.item_name || '') + '</td>' +
                '<td style="padding:8px;border:1px solid #ddd;text-align:center;">' + (item.unit || '') + '</td>' +
                '<td style="padding:8px;border:1px solid #ddd;text-align:center;font-weight:bold;">' + (item.qty_ordered || 0) + '</td>' +
                '<td style="padding:8px;border:1px solid #ddd;text-align:center;">' + _fmtNum(item.unit_price) + '</td>' +
                '<td style="padding:8px;border:1px solid #ddd;text-align:center;font-weight:bold;">' + _fmtNum(lineTotal) + '</td>' +
                '</tr>';
        }
        itemsHtml += '</tbody></table>';
    } else {
        itemsHtml = '<p style="text-align:center;color:#6b7280;margin-top:16px;">لا توجد أصناف مجمعة</p>';
    }

    var html = '<!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8"><title>بيان رحلة - ' + code + '</title>' +
        '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
        '<style>body{font-family:"Cairo",sans-serif;padding:20px;color:#111827;}h1{font-size:24px;margin-bottom:4px;}' +
        'h2{font-size:18px;color:#6b7280;margin-bottom:20px;}' +
        '.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;background:#f9fafb;padding:16px;border-radius:12px;margin-bottom:20px;}' +
        '.info-item label{font-size:12px;color:#6b7280;display:block;}.info-item span{font-weight:bold;font-size:16px;}' +
        '@media print{body{padding:0;}}</style></head><body>' +
        '<h1>بيان رحلة: ' + code + '</h1>' +
        '<h2>التاريخ: ' + (rs.run_date || '') + ' | الحالة: ' + (rs.status || '') + '</h2>' +
        '<div class="info-grid">' +
        '<div class="info-item"><label>السائق</label><span>' + (rs.driver_id || '---') + '</span></div>' +
        '<div class="info-item"><label>السيارة</label><span>' + (rs.vehicle_id || '---') + '</span></div>' +
        '<div class="info-item"><label>عدد الأوردرات</label><span>' + orders.length + '</span></div>' +
        '<div class="info-item"><label>القيمة الإجمالية</label><span>' + _fmtNum(rs.total_amount) + ' EGP</span></div>' +
        '</div>' +
        '<h3 style="margin-top:20px;margin-bottom:8px;">الأوردرات المرتبطة</h3>' +
        '<div style="margin-bottom:20px;">' + ordersHtml + '</div>' +
        '<h3 style="margin-bottom:8px;">الأصناف المجمعة</h3>' +
        itemsHtml +
        '<div style="text-align:left;font-size:20px;font-weight:bold;margin-top:20px;">الإجمالي: ' + _fmtNum(grandTotal) + ' EGP</div>' +
        '<p style="text-align:center;margin-top:40px;color:#9ca3af;font-size:12px;">تم إنشاء هذا البيان بواسطة نظام الروائع ERP</p>' +
        '<script>window.print();<\/script></body></html>';

    printWindow.document.write(html);
    printWindow.document.close();
}
    return {
        render: render, _apply: _apply, _sort: _sort,
        _cancelRunsheet: _cancelRunsheet,
        _changeStatus: _changeStatus,
        _details: _details
    };
})();
window.RW_Runsheets = RW_Runsheets;
